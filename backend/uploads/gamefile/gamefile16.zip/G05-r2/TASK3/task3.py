import requests
import pandas as pd
from bs4 import BeautifulSoup
import re

def fetch_wikipedia_gdp_data():
    url = "https://en.wikipedia.org/wiki/List_of_countries_by_GDP_(nominal)"
    
    # 1. Read website using BeautifulSoup
    response = requests.get(url)
    responses = response.status_code
    
    if responses == 200:
        print(f"Request to {url} successful !!")
        print(f"Status code: {responses} -- OK")
        
        # 2. Check how many tables are on the page
        soup = BeautifulSoup(response.content, 'html.parser')
        tables = soup.find_all('table', {'class': 'wikitable'})
        print(f"The web page contains {len(tables)} tables in total.")
        
        # Define the sources we want to extract
        sources = ["IMF", "World Bank", "United Nations"]
        print("We found 3 header rows indicating info sources as follows.")
        print(sources)
        
        # Create a dictionary to store source-specific tables
        source_tables = {}
        
        # Look for specific GDP tables by examining nearby headings
        for i, table in enumerate(tables):
            # Look for headings near the table
            heading = table.find_previous(['h2', 'h3', 'h4'])
            heading_text = heading.get_text().strip() if heading else ""
            
            # Check if this table belongs to a specific source
            if "IMF" in heading_text or "International Monetary Fund" in heading_text:
                source_tables["IMF"] = table
            elif "World Bank" in heading_text:
                source_tables["World Bank"] = table
            elif "United Nations" in heading_text:
                source_tables["United Nations"] = table
        
        # If we couldn't find all tables by headings, try table content
        if len(source_tables) < 3:
            for i, table in enumerate(tables):
                table_text = table.get_text()
                
                if "IMF" in table_text or "International Monetary Fund" in table_text:
                    if "IMF" not in source_tables:
                        source_tables["IMF"] = table
                
                if "World Bank" in table_text:
                    if "World Bank" not in source_tables:
                        source_tables["World Bank"] = table
                        
                if "United Nations" in table_text:
                    if "United Nations" not in source_tables:
                        source_tables["United Nations"] = table
        
        # If still not found, use the first 3 tables (common pattern in Wikipedia)
        if len(source_tables) < 3:
            for i, source in enumerate(sources):
                if source not in source_tables and i < len(tables):
                    source_tables[source] = tables[i]
        
        # Create DataFrames for each source
        dfs = {}
        
        # Process each source in our defined order
        for source in sources:
            if source in source_tables:
                df = extract_gdp_data(source_tables[source], source)
                dfs[source] = df
                print_dataframe(df)
            else:
                print(f"Could not find table for {source}")
        
        return dfs
    else:
        print(f"Request to {url} failed !!")
        print(f"Status code: {responses} -- Error")
        return None

def extract_gdp_data(table, source):
    """
    Extract data from a GDP table for a specific source
    """
    rows = table.find_all('tr')
    
    # Find the header to determine the GDP column index
    header_cells = rows[0].find_all(['th', 'td'])
    gdp_col_idx = None
    country_col_idx = None
    for idx, cell in enumerate(header_cells):
        text = cell.get_text().strip().lower()
        if 'gdp' in text and ('million' in text or 'usd' in text):
            gdp_col_idx = idx
        if 'country' in text or 'state' in text or 'territory' in text:
            country_col_idx = idx
    if gdp_col_idx is None:
        gdp_col_idx = 2  # fallback
    if country_col_idx is None:
        country_col_idx = 1  # fallback

    ranks = []
    countries = []
    gdps = []
    current_rank = 0  # Start rank at 0

    for row in rows[1:]:  # Skip header row
        row_class = row.get('class', [])
        cells = row.find_all(['td'])
        if len(cells) < 2:
            continue  # skip rows without enough columns

        # Check if this row should have a rank
        if 'static-row-numbers-norank' in row_class:
            rank = ""
        else:
            rank = current_rank
            current_rank += 1

        # Country is always in the first cell
        country_cell = cells[0]
        country_link = country_cell.find('a')
        if country_link:
            country = country_link.get_text().strip()
        else:
            country = country_cell.get_text().strip()
        country = re.sub(r'\[.*?\]', '', country).strip()  # Remove notes like [n 1]

        # GDP is always in the second cell
        gdp_cell = cells[1]
        gdp_text = gdp_cell.get_text().strip()
        gdp_text = re.sub(r'\[.*?\]', '', gdp_text)  # Remove notes
        gdp_text = re.sub(r'\s*\(\d{4}\)', '', gdp_text)
        gdp_text = gdp_text.replace(',', '').replace('—', '').strip()
        gdp = gdp_text if gdp_text else None

        ranks.append(rank)
        countries.append(country)
        gdps.append(gdp)
    # Create DataFrame
    df = pd.DataFrame({
        'Rank': ranks,
        'Country': countries,
        f'GDP (million US$) by {source}': gdps
    })

    return df

def print_dataframe(df):
    """
    Print the dataframe in the specified format, with aligned columns
    """
    source = df.columns[2].split('by ')[1]
    # Set column widths
    idx_width = 5
    rank_width = 5
    country_width = 35
    gdp_width = 18
    separator_length = idx_width + rank_width + country_width + gdp_width + 10

    print('-' * separator_length)
    print(f"{'Index':<{idx_width}}\t{'Rank':<{rank_width}}\t{'Country':<{country_width}}{df.columns[2]:>{gdp_width}}")
    print('-' * separator_length)
    for i, row in df.iterrows():
        # Handle rank display
        if row['Rank'] == "" or pd.isna(row['Rank']):
            rank_display = ""
        else:
            rank_display = int(row['Rank'])

        # Format GDP value with commas
        gdp_value = row[df.columns[2]]
        if pd.isna(gdp_value):
            gdp_display = "—"
        else:
            try:
                gdp_float = float(gdp_value)
                gdp_display = f"{int(gdp_float):,}"
            except (ValueError, TypeError):
                gdp_display = gdp_value

        print(f"{str(i):<{idx_width}}\t{str(rank_display):<{rank_width}}\t{row['Country']:<{country_width}}{gdp_display:>{gdp_width}}")
    print('-' * separator_length)

# Execute the main function
gdp_dataframes = fetch_wikipedia_gdp_data()