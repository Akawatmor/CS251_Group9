การรันโค้ดของโปรแกรม task1.py มีการใช้งาน library เหล่านี้
- requests => จัดการการรับข้อมูลจากเว็บไซต์
- beautifulsoup4 => จัดการแปลงข้อมูลให้สวยงามเป็นระบบ
- regex => ตัด/จัดการบางส่วนข้อความที่ตรงกับ Regular Expression

โปรดติดตั้ง module เหล่านี้ใน venv โดยใช้คำสั่ง
pip install requests beautifulsoup4 regex
ในโปรแกรมมีการ import library ที่กำหนดไว้แล้ว ไม่จำเป็นต้องประกาศซ้ำ