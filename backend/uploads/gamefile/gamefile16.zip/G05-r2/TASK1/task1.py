
import requests, re
from bs4 import BeautifulSoup

URL = "https://www.gutenberg.org/browse/scores/top"

# 1. check_response(url) function
# Check if the URL is reachable and returns a successful response.
def check_response(url):
    try:
        response = requests.get(url)

        if response.status_code == 200:
            print("Web response success !")
            return 0
        else:
            print("Web response failed !")
            return 1
    except:
        print("Web response failed !")
        return 1

## 2. get_all_href_on_page(soup) function
# Get all tag a href links on the page.
def get_all_href_on_page(soup):
    href_list = []
    for link in soup.find_all('a', href=True):
        href_list.append(link['href'])

    return href_list

## 3. get_top100_filenumbers_on_page(href_list) function
# Get the first 100 file numbers from the href list.
def get_top100_filenumbers_on_page(href_list):
    file_id = []
    for hl in href_list:
        if re.search(r'/ebooks/\d+', hl):
            file_id.append(int(re.search(r'\d+', hl).group()))

    return file_id[:100]

## 4. get_top100_ebooks_Yesterday(soup) function
# Get the top 100 ebooks from yesterday's list.
def get_top100_ebooks_Yesterday(soup):
    
    End = 100
    Adjust = 2
    all_text = soup.text
    text_line = all_text.splitlines()
    start_index = text_line.index("Top 100 EBooks yesterday")

    temp_book_list = text_line[start_index+Adjust:start_index+Adjust+End]

    top_ebook_yesterday = []
    for tbl in temp_book_list:
        temp = re.match(r'^(.*?)(?=\s\(\d+\)$)', tbl)
        top_ebook_yesterday.append(temp.group(0))

    return top_ebook_yesterday

#Driver code
if __name__ == "__main__":
    print("="*20 + " 1. Function check_response " + "="*20)
    cond = check_response(URL)
    if cond == 0:
        response = requests.get(URL)
        soup = BeautifulSoup(response.content, 'html.parser')

        
        print("="*20 + " 2. Function get_all_href_on_soup " + "="*20)
        href_list = get_all_href_on_page(soup)
        for hl in href_list[:100]:
            print(hl)

        print("="*20 + " 3. Function get_top100_filenumbers_on_page " + "="*20)
        file_id = get_top100_filenumbers_on_page(href_list)
        #print("number:", len(file_id), file_id)
        print(file_id)

        print("="*20 + " 4. Function get_top100_ebooks_Yesterday " + "="*20)
        top_ebook_yesterday = get_top100_ebooks_Yesterday(soup)
        #print("get:", (len(top_ebook_yesterday)))
        for bl in top_ebook_yesterday:
            print(bl)
    else:
        print("The URL is not reachable or the response is not successful.")