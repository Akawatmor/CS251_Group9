import urllib.request, urllib.parse, urllib.error, json

#Configuartion
serviceurl = "http://www.omdbapi.com/?"
apikey = "&apikey=d8c07a03"
studentID = "6609681238_6609681231"

# 1.print_json(data) function
## Print the JSON data in a readable format.
def print_json(data):
    for line in data:
        print(line, ":", data[line])

# 2.save_poster(data) function
## Save the movie poster to a file.
def save_poster(data):
    filename = data['Title'] + "_poster_" + str(studentID) + ".jpg"
    #print(data['Poster'])
    try:
        print("Saving poster to", filename)
        urllib.request.urlretrieve(data['Poster'], filename)
        print("Poster saved successfully")
    except:
        print("Error in saving poster")
        


# 3.search_movie(title) function
## Search for a movie by title and return the JSON data.
def search_movie(title):
    
    request = "t=" + urllib.parse.quote(title)

    requesturl = serviceurl + request + apikey
    #print(requesturl)

    try:
        response = urllib.request.urlopen(requesturl)
        data = response.read().decode()
        js = json.loads(data)
        return js
    
    except:
        print("Error in fetching movie data")
        return None

# Driver code
if __name__ == "__main__":
    print("="*20 + " 3. search movie " + "="*20)
    movie = search_movie("Titanic")
    print(movie)

    print("="*20 + " 1. print_json " + "="*20)
    print_json(movie)

    print("="*20 + " 2. save_poster " + "="*20)
    save_poster(movie)

    