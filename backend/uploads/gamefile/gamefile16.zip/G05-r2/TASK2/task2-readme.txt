การรันโค้ดของโปรแกรม task2.py มีการใช้งาน library เหล่านี้
- urllib3 => จัดการ http request
- json => จัดการข้อมูล json ให้ใช้งานได้ง่าย (คล้าย dict)

โปรดติดตั้ง module เหล่านี้ใน venv โดยใช้คำสั่ง
pip install urllib3 json
ในโปรแกรมมีการ import library ที่กำหนดไว้แล้ว ไม่จำเป็นต้องประกาศซ้ำ